from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
import random 
from .models import Seller, listing, Buyer
from django.contrib import messages
from django.contrib.auth import authenticate, login as auth_login
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User

from .forms import SellerReg, SellerLogForm, BuyerLogForm, BuyerReg

# Create your views here.
def index(request):
    return render(request, "home/login.html")

def AddListing(request):
    return render(request, "home/AddListing.html")

def AccountSeller(request):
    return render(request, "home/AccountSeller.html")

def logout(request):
    return render(request, "home/logout.html")

def login(request):
    return render(request, "home/login.html")

def Create_Account(request):
    return render(request, "home/Create_Account.html")

def Create_AccountBuy(request):
    return render(request, "home/Create_AccountBuy.html")

def loginbuy(request):
    return render(request, "home/loginbuy.html")

def AccountUser(request):
    return render(request, "home/AccountUser.html")




#Cart Functions
def Buyer_Home(request):
    listings = listing.objects.all()
    return render(request, "home/Buyer_Home.html",  {'listings': listings})


def add_to_cart(request, book_id):
    book = get_object_or_404(listing, pk=book_id)
    cart = request.session.get('cart', {})
    if str(book_id) in cart:
        #if book is already in cart, increase quantity
        cart[str(book_id)] += 1
    else:
        #if book is not in cart
        cart[str(book_id)] = 1
    request.session['cart'] = cart
    return redirect('Buyer_Home')


def User_Cart(request):
    cart = request.session.get('cart', {})
    #book_ids = list(cart.keys())
    #in_cart = listing.objects.filter(pk__in=book_ids)
    #cart_items = [{'book': book, 'quantity': cart[str(book.id)]} for book in in_cart]
    cart_items = []
    total_price = 0
    for book_id, quantity in cart.items():
        book = get_object_or_404(listing, pk=book_id)
        cart_items.append({'book':book, 'quantity':quantity})
        total_price += book.price * quantity
    return render(request, 'home/User_Cart.html', {'cart_items': cart_items, 'total_price': total_price})



def delete_from_cart(request, book_id):
    if 'cart' in request.session:
        cart = request.session['cart']
        if str(book_id) in cart:
            del cart[str(book_id)]
            request.session['cart'] = cart
    return redirect('User_Cart')
#end of cart functions


#Seller Create account and login
def reg_seller(request):
    if request.method == 'POST':
        form = SellerReg(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            balance = 0
            
            user = User.objects.create_user(email=email, username=username, password=password)
            new_seller = Seller(user=user, email=email, username=username, balance=balance)
            new_seller.save()
            return redirect('login')


    else:
        form = SellerReg()
    return render(request, 'home/Create_Account.html', {'form': form})


def sellerlogin(request):
    if request.method == 'POST':
        form = SellerLogForm(request.POST)

        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                auth_login(request, user)
                return redirect('AccountSeller')
            else:
                form.add_error(None, 'Invalid username or password.')
    
    else:
        form = SellerLogForm()
    return render(request, 'home/login.html', {'form': form})


#BUYER Create account and login
def reg_buyer(request):
    if request.method == 'POST':
        form = BuyerReg(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            
            user = User.objects.create_user(email=email, username=username, password=password)
            new_buyer = Buyer(user=user, email=email, username=username)
            new_buyer.save()
            return redirect('loginbuy')


    else:
        form = BuyerReg()
    return render(request, 'home/Create_AccountBuy.html', {'form': form})


def buyerlogin(request):
    if request.method == 'POST':
        form = BuyerLogForm(request.POST)

        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                auth_login(request, user)
                return redirect('AccountUser')
            else:
                form.add_error(None, 'Invalid username or password.')
    
    else:
        form = BuyerLogForm()
    return render(request, 'home/loginbuy.html', {'form': form})


@login_required
def UpdateUser(request):
    try:
        # Get the current buyer associated with the user
        buyer = Buyer.objects.get(User_ID=request.user.username)
    except Buyer.DoesNotExist:
        return HttpResponse("Buyer matching query does not exist.")  # Or render a specific template
    else:
        if request.method == 'POST':
            new_username = request.POST.get('username')
            if new_username:
                buyer.username = new_username
                buyer.save()
                return redirect('profile')  # Redirect to profile page after successful update
        return render(request, 'update_username.html', {'buyer': buyer})
    

@login_required
def createlisting(request):
    if request.method == 'POST':
        # Retrieve listing details from the form
        title = request.POST.get('title')
        author = request.POST.get('author')
        year = request.POST.get('year')
        quantity = request.POST.get('quantity')
        isbn = request.POST.get('isbn')
        price = request.POST.get('price')
        seller = Seller.objects.get(user=request.user)
        #images

        # Create a new Listing object
        new_listing = listing(
            title=title,
            author=author,
            year=year,
            quantity=quantity,
            isbn=isbn,
            price=price,
            seller=seller,
            
            
        )
        new_listing.save()

        # Redirect to a success page or another page
        return redirect('AccountSeller')  # Assuming 'home' is the name of the home page URL pattern

    return render(request, 'home/AddListing.html')  # Render the listing creation form