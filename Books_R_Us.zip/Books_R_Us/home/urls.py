from django.urls import path
from . import views




urlpatterns = [
    path('', views.index, name="index") ,

    path('reg_seller/', views.reg_seller, name='reg_seller'),
    path('reg_buyer/', views.reg_buyer, name='reg_buyer'),

    path('AddListing/', views.AddListing, name="AddListing"),
    path('AccountSeller/', views.AccountSeller, name="AccountSeller"),
    path('logout/', views.logout, name="logout"),
    path('login/', views.login, name="login"),
    path('Create_Account/', views.Create_Account, name="Create_Account"),
    
    path('sellerlogin/', views.sellerlogin, name='sellerlogin'),
    path('createlisting/', views.createlisting, name="createlisting"),
    path('Create_AccountBuy/', views.Create_AccountBuy,name='Create_AccountBuy'),
    path('loginbuy/', views.loginbuy, name='loginbuy'),
    path('buyerlogin/', views.buyerlogin, name="buyerlogin"),

    path('AccountUser/', views.AccountUser, name='AccountUser'),
    path('UpdateUser/', views.UpdateUser, name='UpdateUser'),


    path('Buyer_Home/', views.Buyer_Home, name='Buyer_Home'),
    path('add_to_cart/<int:book_id>/', views.add_to_cart, name='add_to_cart'),
    path('User_Cart/', views.User_Cart, name='User_Cart'),
    path('delete_from_cart/<int:book_id>/', views.delete_from_cart, name='delete_from_cart'),
]