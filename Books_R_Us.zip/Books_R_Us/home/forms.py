from django import forms
from django.contrib.auth.models import User

#Creating new SELLER account
class SellerReg(forms.Form):
    email = forms.EmailField()
    username=forms.CharField(max_length=100)
    password = forms.CharField()
    
#Login to SELLER account
class SellerLogForm(forms.Form):
    username = forms.CharField(max_length=100)
    password = forms.CharField()

#Creating new BUYER account
class BuyerReg(forms.Form):
    email = forms.EmailField()
    username=forms.CharField(max_length=100)
    password = forms.CharField()

#Login to new BUYER account
class BuyerLogForm(forms.Form):
    username = forms.CharField(max_length=100)
    password = forms.CharField()