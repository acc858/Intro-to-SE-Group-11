from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from database.db_functions import delete, insert, select, update 
from classes import cart, inventory, order, users 
from create_account import create
from login import user_crypto, user_history, user_login
from menu import main 
from django.http import JsonResponse
from classes.inventory import Inventory
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
import random 
from classes.users import User
from login.user_login import login_page
from .models import Seller, listing, Cart, Buyer
from django.contrib import messages
from django.contrib.auth import authenticate, login as auth_login
from django.contrib.auth.decorators import login_required

import os
from django.conf import settings
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile




# Create your views here.
def index(request):
    return render(request, "home/login.html")

def AddListing(request):
    return render(request, "home/AddListing.html")

def AccountSeller(request):
    return render(request, "home/AccountSeller.html")

def logout(request):
    return render(request, "home/logout.html")

def login(request):
    return render(request, "home/login.html")

def Create_Account(request):
    return render(request, "home/Create_Account.html")

def Create_AccountBuy(request):
    return render(request, "home/Create_AccountBuy.html")

def loginbuy(request):
    return render(request, "home/loginbuy.html")

def AccountUser(request):
    return render(request, "home/AccountUser.html")



#Cart Functions
def Buyer_Home(request):
    listings = listing.objects.all()
    return render(request, "home/Buyer_Home.html",  {'listings': listings})


def add_to_cart(request, book_id):
    book = get_object_or_404(listing, pk=book_id)
    cart = request.session.get('cart', {})
    if str(book_id) in cart:
        #if book is already in cart, increase quantity
        cart[str(book_id)] += 1
    else:
        #if book is not in cart
        cart[str(book_id)] = 1
    request.session['cart'] = cart
    return redirect('Buyer_Home')


def User_Cart(request):
    cart = request.session.get('cart', {})
    #book_ids = list(cart.keys())
    #in_cart = listing.objects.filter(pk__in=book_ids)
    #cart_items = [{'book': book, 'quantity': cart[str(book.id)]} for book in in_cart]
    cart_items = []
    total_price = 0
    for book_id, quantity in cart.items():
        book = get_object_or_404(listing, pk=book_id)
        cart_items.append({'book':book, 'quantity':quantity})
        total_price += book.price * quantity
    return render(request, 'home/User_Cart.html', {'cart_items': cart_items, 'total_price': total_price})



def delete_from_cart(request, book_id):
    if 'cart' in request.session:
        cart = request.session['cart']
        if str(book_id) in cart:
            del cart[str(book_id)]
            request.session['cart'] = cart
    return redirect('User_Cart')

#end of cart functions









def createaccount(request):
     if request.method == 'POST':
        # Retrieve user input from the form
        email = request.POST.get('email')
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        # Create a new User object
        new_user = User.objects.create_user(username=username, email=email, password=password)

        # Create a new Seller object
        new_seller = Seller(user=new_user, email=email, username=username, balance=0)
        new_seller.save()

        # Redirect to a success page or login page
        return redirect('login')  # Assuming 'login' is the name of the login page URL pattern
        

     return render(request, 'Create_Account.html')  # Render the account creation form

def sellerlogin(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        # Check if the username and password are correct
        user = authenticate(username=username, password=password)
        if user is not None:
            # Log in the user
            login(request)
            return redirect('AccountSeller')  # Assuming 'account' is the name of the account page URL pattern
        else:
            messages.error(request, 'Invalid username or password.')
    
    return render(request, 'home/login.html')

def createlisting(request):
    if request.method == 'POST':
        # Retrieve listing details from the form
        title = request.POST.get('title')
        author = request.POST.get('author')
        year = request.POST.get('year')
        quantity = request.POST.get('quantity')
        isbn = request.POST.get('isbn')
        price = request.POST.get('price')
        
        #images
        image_file = request.FILES.get('image')
        if image_file:
            #save image to media directory
            image_name= image_file.name
            image_path = os.path.join(settings.MEDIA_ROOT, image_name)
            with default_storage.open(image_path, 'wb+') as destination:
                for chunk in image_file.chunks():
                    destination.write(chunk)
            image_url = os.path.join(settings.MEDIA_URL, image_name)
        else:
            image_url = None

        # Create a new Listing object
        new_listing = listing(
            title=title,
            author=author,
            year=year,
            quantity=quantity,
            isbn=isbn,
            price=price,
            image=image_url,
            
        )
        new_listing.save()

        # Redirect to a success page or another page
        return redirect('AccountSeller')  # Assuming 'home' is the name of the home page URL pattern

    return render(request, 'home/AddListing.html')  # Render the listing creation form

def createbuyaccount(request):
    if request.method == 'POST':
        # Retrieve user input from the form
        
        email = request.POST.get('email')
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        
        # Generate a random user ID
        userid = random.randint(0, 10000)
        

        # Create a new User object
        new_user = Buyer(Email=email, Username=username, Password=password, User_ID=userid)
        new_user.save()

        # Redirect to a success page or login page
        return redirect('loginbuy')  # Assuming 'login' is the name of the login page URL pattern

    return render(request, 'Create_AccountBuy.html')  # Render the account creation form

def buyerlogin(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        try:
            buyer = Buyer.objects.get(Username=username)
        except Buyer.DoesNotExist:
            messages.error(request, 'Buyer does not exist.')
            return render(request, 'home/loginbuy.html')
        
        # Check if the provided password matches the hashed password stored in the Seller model
        if password == buyer.Password:
            # Log in the seller
            request.session['buyer_id'] = buyer.User_ID
            return redirect('AccountUser')  
        else:
            messages.error(request, 'Incorrect password.')
            return render(request, 'home/loginbuy.html')
    
    return render(request, 'home/loginbuy.html')


@login_required
def UpdateUser(request):
    try:
        # Get the current buyer associated with the user
        buyer = Buyer.objects.get(User_ID=request.user.username)
    except Buyer.DoesNotExist:
        return HttpResponse("Buyer matching query does not exist.")  # Or render a specific template
    else:
        if request.method == 'POST':
            new_username = request.POST.get('username')
            if new_username:
                buyer.username = new_username
                buyer.save()
                return redirect('profile')  # Redirect to profile page after successful update
        return render(request, 'update_username.html', {'buyer': buyer})
    