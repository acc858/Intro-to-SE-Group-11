from django.contrib import admin
from .models import listing, Cart, Seller, Buyer

admin.site.register(listing)
admin.site.register(Cart)
admin.site.register(Seller)
admin.site.register(Buyer)
# Register your models here.
