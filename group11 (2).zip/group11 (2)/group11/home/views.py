from django.shortcuts import render, redirect
from django.http import HttpResponse
from database.db_functions import delete, insert, select, update 
from classes import cart, inventory, order, users 
from create_account import create
from login import user_crypto, user_history, user_login
from menu import main 
from django.http import JsonResponse
from classes.inventory import Inventory
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
import random 
from classes.users import User
from login.user_login import login_page
from .models import Seller, listing, Cart, Buyer
from django.contrib import messages
from django.contrib.auth import authenticate, login as auth_login
from .models import listing
from .forms import SearchForm
from django.db import models
from django.db.models import Q


# Create your views here.
def index(request):
    return render(request, "home/login.html")

def AddListing(request):
    return render(request, "home/AddListing.html")

def AccountSeller(request):
    return render(request, "home/AccountSeller.html")

def logout(request):
    return render(request, "home/logout.html")

def login(request):
    return render(request, "home/login.html")

def Create_Account(request):
    return render(request, "home/Create_Account.html")

def Create_AccountBuy(request):
    return render(request, "home/Create_AccountBuy.html")

def loginbuy(request):
    return render(request, "home/loginbuy.html")

def AccountUser(request):
    return render(request, "home/AccountUser.html")

def Buyer_Home(request):
    listings = listing.objects.all()
    return render(request, "home/Buyer_Home.html",  {'listings': listings})

def createaccount(request):
    if request.method == 'POST':
        # Retrieve user input from the form
        
        email = request.POST.get('email')
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        
        # Generate a random user ID
        userid = random.randint(0, 10000)
        

        # Create a new User object
        new_user = Seller(Email=email, Username=username, Password=password, User_ID=userid)
        new_user.save()

        # Redirect to a success page or login page
        return redirect('login')  # Assuming 'login' is the name of the login page URL pattern

    return render(request, 'Create_Account.html')  # Render the account creation form

def sellerlogin(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        try:
            seller = Seller.objects.get(Username=username)
        except Seller.DoesNotExist:
            messages.error(request, 'Seller does not exist.')
            return render(request, 'home/login.html')
        
        # Check if the provided password matches the hashed password stored in the Seller model
        if password == seller.Password:
            # Log in the seller
            request.session['seller_id'] = seller.User_ID
            return redirect('AccountSeller')  # Assuming 'AccountSeller' is the name of the account seller page URL pattern
        else:
            messages.error(request, 'Incorrect password.')
            return render(request, 'home/login.html')
    
    return render(request, 'home/login.html')

def createlisting(request):
    if request.method == 'POST':
        # Retrieve listing details from the form
        title = request.POST.get('title')
        author = request.POST.get('author')
        year = request.POST.get('year')
        quantity = request.POST.get('quantity')
        isbn = request.POST.get('isbn')
        price = request.POST.get('price')
        
        # Generate a random listing ID
        
        
        # Create a new Listing object
        new_listing = listing(
            title=title,
            author=author,
            year=year,
            quantity=quantity,
            isbn=isbn,
            price=price,
            
        )
        new_listing.save()

        # Redirect to a success page or another page
        return redirect('AccountSeller')  # Assuming 'home' is the name of the home page URL pattern

    return render(request, 'home/AddListing.html')  # Render the listing creation form

def createbuyaccount(request):
    if request.method == 'POST':
        # Retrieve user input from the form
        
        email = request.POST.get('email')
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        
        # Generate a random user ID
        userid = random.randint(0, 10000)
        

        # Create a new User object
        new_user = Buyer(Email=email, Username=username, Password=password, User_ID=userid)
        new_user.save()

        # Redirect to a success page or login page
        return redirect('loginbuy')  # Assuming 'login' is the name of the login page URL pattern

    return render(request, 'Create_AccountBuy.html')  # Render the account creation form

def buyerlogin(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        try:
            buyer = Buyer.objects.get(Username=username)
        except Buyer.DoesNotExist:
            messages.error(request, 'Buyer does not exist.')
            return render(request, 'home/loginbuy.html')
        
        # Check if the provided password matches the hashed password stored in the Seller model
        if password == buyer.Password:
            # Log in the seller
            request.session['buyer_id'] = buyer.User_ID
            return redirect('AccountUser')  
        else:
            messages.error(request, 'Incorrect password.')
            return render(request, 'home/loginbuy.html')
    
    return render(request, 'home/loginbuy.html')


def search(request):
    form = SearchForm(request.GET)
    listings = None
    if form.is_valid():
        query = form.cleaned_data['query']
        listings = listing.objects.filter(models.Q(title__icontains=query) | models.Q(isbn__icontains=query))
    return render(request, 'search.html', {'form': form, 'listings': listings})