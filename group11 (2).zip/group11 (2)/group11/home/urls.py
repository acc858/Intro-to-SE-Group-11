from django.urls import path
from . import views
from django.urls import path, include



urlpatterns = [
    path('', views.index, name="index") ,
    path('AddListing/', views.AddListing, name="AddListing"),
    path('AccountSeller/', views.AccountSeller, name="AccountSeller"),
    path('logout/', views.logout, name="logout"),
    path('login/', views.login, name="login"),
    path('Create_Account/', views.Create_Account, name="Create_Account"),
    path('createaccount/', views.createaccount, name="createaccount"),
    path('sellerlogin/', views.sellerlogin, name='sellerlogin'),
    path('createlisting/', views.createlisting, name="createlisting"),
    path('createbuyaccount/', views.createbuyaccount, name='createbuyaccount'),
    path('Create_AccountBuy/', views.Create_AccountBuy,name='Create_AccountBuy'),
    path('loginbuy/', views.loginbuy, name='loginbuy'),
    path('buyerlogin/', views.buyerlogin, name="buyerlogin"),
    path('AccountUser/',views.AccountUser, name='AccountUser'),
    path('Buyer_Home/', views.Buyer_Home, name='Buyer_Home'),
    path('search/', views.search, name='search'),
    path('books/', include('booksearch.urls')),
]