from django.db import models
from django.contrib.auth.models import User  # Import the User model if you're using it
class listing(models.Model):
    title=models.CharField(max_length=200)
    author=models.CharField(max_length=200)
    year=models.IntegerField()
    quantity=models.IntegerField()
    isbn=models.IntegerField()
    price=models.IntegerField()

    def __str__(self):
        return self.title


class Cart(models.Model):
    ISBN = models.IntegerField()
    Title = models.CharField(max_length=50)
    Author = models.CharField(max_length=50)
    Year = models.IntegerField()
    Genre = models.CharField(max_length=50)
    User_ID = models.ForeignKey(User, on_delete=models.CASCADE)  # Assuming a ForeignKey relationship with User model
    Quantity = models.IntegerField()
    Price = models.IntegerField()
# Create your models here.
class Seller(models.Model):
    Email = models.TextField()
    Username = models.TextField()
    Password = models.TextField()
    User_ID = models.IntegerField(primary_key=True)

    def __str__(self):
        return self.Email
    

class Buyer(models.Model):
    Email = models.TextField()
    Username = models.TextField()
    Password = models.TextField()
    User_ID = models.IntegerField(primary_key=True)

    def __str__(self):
        return self.Email