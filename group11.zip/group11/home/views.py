from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from database.db_functions import delete, insert, select, update 
from classes import cart, inventory, order, users 
from create_account import create
from login import user_crypto, user_history, user_login
from menu import main 
from django.http import JsonResponse
from classes.inventory import Inventory
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
import random 
from classes.users import User
from django.contrib.auth.models import User
from login.user_login import login_page
from .models import Seller, UserProfile, listing, Cart, Buyer
from django.contrib import messages
from django.contrib.auth import authenticate, login as auth_login
from django.contrib.auth.decorators import login_required
from .forms import SearchForm
from django.db import models
from django.db.models import Q


# Create your views here.
def index(request):
    return render(request, "home/login.html")

def AddListing(request):
    return render(request, "home/AddListing.html")

def AccountSeller(request):
    return render(request, "home/AccountSeller.html")

def logout(request):
    return render(request, "home/logout.html")

def login(request):
    return render(request, "home/login.html")

def login_view(request):
    return render(request, "home/login.html")


def Create_AccountBuy(request):
    return render(request, "home/Create_AccountBuy.html")

def loginbuy(request):
    return render(request, "home/loginbuy.html")

def AccountUser(request):
    return render(request, "home/AccountUser.html")



#Cart Functions
def Buyer_Home(request):
    listings = listing.objects.all()
    return render(request, "home/Buyer_Home.html",  {'listings': listings})


def add_to_cart(request, book_id):
    book = get_object_or_404(listing, pk=book_id)
    cart = request.session.get('cart', {})
    if str(book_id) in cart:
        #if book is already in cart, increase quantity
        cart[str(book_id)] += 1
    else:
        #if book is not in cart
        cart[str(book_id)] = 1
    request.session['cart'] = cart
    return redirect('Buyer_Home')


def User_Cart(request):
    cart = request.session.get('cart', {})
    #book_ids = list(cart.keys())
    #in_cart = listing.objects.filter(pk__in=book_ids)
    #cart_items = [{'book': book, 'quantity': cart[str(book.id)]} for book in in_cart]
    cart_items = []
    total_price = 0
    for book_id, quantity in cart.items():
        book = get_object_or_404(listing, pk=book_id)
        cart_items.append({'book':book, 'quantity':quantity})
        total_price += book.price * quantity
    return render(request, 'home/User_Cart.html', {'cart_items': cart_items, 'total_price': total_price})



def delete_from_cart(request, book_id):
    if 'cart' in request.session:
        cart = request.session['cart']
        if str(book_id) in cart:
            del cart[str(book_id)]
            request.session['cart'] = cart
    return redirect('User_Cart')

#end of cart functions












from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from .models import UserProfile, Seller, Buyer

def createaccount(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        role = request.POST.get('role')

        try:
            new_user = User.objects.create_user(username=username, email=email, password=password)
            new_user_profile = UserProfile.objects.create(user=new_user, role=role, email=email)

            if role == 'seller':
                new_seller = Seller(user=new_user, balance=0)
                new_seller.save()
            elif role == 'buyer':
                new_buyer = Buyer(user=new_user)
                new_buyer.save()

            return redirect('login')
        except Exception as e:
            # Handle the error and inform the user
            return render(request, 'Create_Account.html', {'error': str(e)})

    return render(request, 'Create_Account.html')

from django.contrib.auth import authenticate, login as auth_login

def login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            auth_login(request, user)
            return redirect('AccountUser')  
        else:
            messages.error(request, "Invalid username or password.")
    return render(request, 'home/login.html')



def sellerlogin(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        # Check if the username and password are correct
        user = authenticate(username=username, password=password)
        if user is not None:
            # Log in the user
            login(request)
            return redirect('AccountSeller')  # Assuming 'account' is the name of the account page URL pattern
        else:
            messages.error(request, 'Invalid username or password.')
    
    return render(request, 'home/login.html')

def createlisting(request):
    if request.method == 'POST':
        # Retrieve listing details from the form
        title = request.POST.get('title')
        author = request.POST.get('author')
        year = request.POST.get('year')
        quantity = request.POST.get('quantity')
        isbn = request.POST.get('isbn')
        price = request.POST.get('price')
        
        # Generate a random listing ID
        
        
        # Create a new Listing object
        new_listing = listing(
            title=title,
            author=author,
            year=year,
            quantity=quantity,
            isbn=isbn,
            price=price,
            
        )
        new_listing.save()

        # Redirect to a success page or another page
        return redirect('AccountSeller')  # Assuming 'home' is the name of the home page URL pattern

    return render(request, 'home/AddListing.html')  # Render the listing creation form

def createbuyaccount(request):
    if request.method == 'POST':
        # Retrieve user input from the form
        
        email = request.POST.get('email')
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        
        # Generate a random user ID
        userid = random.randint(0, 10000)
        

        # Create a new User object
        new_user = Buyer(Email=email, Username=username, Password=password, User_ID=userid)
        new_user.save()

        # Redirect to a success page or login page
        return redirect('loginbuy')  # Assuming 'login' is the name of the login page URL pattern

    return render(request, 'Create_AccountBuy.html')  # Render the account creation form

def buyerlogin(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        buyer = authenticate(request, username=username, password=password)
        if buyer:
            auth_login(request, buyer)      
            return redirect('AccountUser')
        else:
            messages.error(request, 'Invalid login attempt.')
    return render(request, 'home/loginbuy.html')



@login_required
def UpdateUser(request):
    try:
        # Get the current buyer associated with the user
        buyer = Buyer.objects.get(User_ID=request.User_ID)
    except Buyer.DoesNotExist:
        return HttpResponse("Buyer matching query does not exist.")  # Or render a specific template
    else:
        if request.method == 'POST':
            new_username = request.POST.get('username')
            if new_username:
                buyer.username = new_username
                buyer.save()
                return redirect('profile')  # Redirect to profile page after successful update
        return render(request, 'update_username.html', {'buyer': buyer})
    return render(request, "home/UpdateUser.html")

def search(request):
    form = SearchForm(request.GET)
    listings = None
    if form.is_valid():
        query = form.cleaned_data['query']
        listings = listing.objects.filter(models.Q(title__icontains=query) | models.Q(isbn__icontains=query))
    return render(request, 'search.html', {'form': form, 'listings': listings})