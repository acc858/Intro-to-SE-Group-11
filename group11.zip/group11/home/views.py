from django.shortcuts import render
from django.http import HttpResponse
from database.db_functions import delete, insert, select, update 
from classes import cart, inventory, order, users 
from create_account import create
from login import user_crypto, user_history, user_login
from menu import main 
from django.http import JsonResponse
from classes.inventory import Inventory
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
# Create your views here.
def index(request):
    return render(request, "home/AccountSeller.html")

def AddListing(request):
    return render(request, "home/AddListing.html")

def AccountSeller(request):
    return render(request, "home/AccountSeller.html")

def logout(request):
    return render(request, "home/logout.html")

def login(request):
    return render(request, "home/login.html")

def Create_Account(request):
    return render(request, "home/Create_Account.html")