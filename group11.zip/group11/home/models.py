from django.db import models
class listing(models.Model):
    title=models.CharField(max_length=200)
    author=models.CharField(max_length=200)
    year=models.IntegerField()
    quantity=models.IntegerField()
    isbn=models.IntegerField()
    price=models.IntegerField()

    def __str__(self):
        return self.title

# Create your models here.
