from django.db import models
from django.contrib.auth.models import User  # Import the User model if you're using it
from django.db import models

class listing(models.Model):
    title = models.CharField(max_length=200)
    author = models.CharField(max_length=200)
    year = models.IntegerField()
    quantity = models.IntegerField()
    isbn = models.IntegerField()
    price = models.IntegerField()

    def __str__(self):
        return self.title
    

class Seller(models.Model):
    Email = models.TextField()
    Username = models.TextField()
    Password = models.TextField()
    User_ID = models.IntegerField(primary_key=True)

    def __str__(self):
        return self.Email
    

class Buyer(models.Model):
    Email = models.TextField()
    Username = models.TextField()
    Password = models.TextField()
    User_ID = models.IntegerField(primary_key=True)

    def __str__(self):
        return self.Email

class Cart(models.Model):
    isbn = models.IntegerField()
    title = models.CharField(max_length=50)
    author = models.CharField(max_length=50)
    year = models.IntegerField()
    genre = models.CharField(max_length=50)
    user = models.ForeignKey(User, on_delete=models.CASCADE)  # ForeignKey relationship with User model
    quantity = models.IntegerField()
    price = models.IntegerField()



class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    role = models.CharField(max_length=50)  # Field to store user role
    email = models.EmailField()  # User profile-specific email

    def __str__(self):
        return self.user.username
