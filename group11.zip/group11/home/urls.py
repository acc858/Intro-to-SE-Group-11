from django.urls import path
from . import views


urlpatterns = [
    path('', views.index, name="index") ,
    path('AddListing/', views.AddListing, name="AddListing"),
    path('AccountSeller/', views.AccountSeller, name="AccountSeller"),
    path('logout/', views.logout, name="logout"),
    path('login/', views.login, name="login"),
    path('Create_Account/', views.Create_Account, name="Create_Account"),



    
]