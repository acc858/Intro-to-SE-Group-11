from django.contrib import admin
from .models import listing

admin.site.register(listing)
# Register your models here.
