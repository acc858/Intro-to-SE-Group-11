from django.contrib import admin
from .models import listing, Cart

admin.site.register(listing)
admin.site.register(Cart)
# Register your models here.
