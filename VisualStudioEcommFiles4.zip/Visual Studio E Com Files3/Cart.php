<!DOCTYPE html>
<html>

<head>
    <title>
        "Cart"
    </title>

    <link rel="stylesheet" href="listingstyle.css">
    <link rel="stylesheet" href="AccountStyle.css">   
</head>

<body>
    <h2>
    <div class="links">
    <ul>
    <li> <a href='AccountUser.html' style="text-decoration: none;" >Account</a> </li>
    <li> <a href='ViewCurrent.html' style="text-decoration: none;">View Current Listings</a></li>
    <li> <a href='Cart.html' style="text-decoration: none;">Cart</a></li>
    <li> <a href='logout.html' style="text-decoration: none;"> Logout</a></li>
    </ul>
    </div>
</h2>
    <div class="main">
    <h1>Cart</h1>

    <table>
    <tr>
        <th>ISBN</th>
        <th>Title</th>
        <th>Price</th>
    </tr>
    <?php
        $conn = mysqli_connect("localhost", "root", "", "company");
        if ($conn-> connect_error) {
            die("connection failed:". $conn->connect_error);
        }

        $sql = "SELECT ISBN, Title, Price, Quantity from Cart";
        $result = $conn-> query($sql);

        if ($result-> num_rows > 0) {
            while ($row = $result-> fetch_assoc()){
                echo "<tr><td>".$row["ISBN"]."<tr><td>".$row["Title"]."<tr><td>".$row["Price"]."<tr><td>".$row["Quantity"]."<tr><td>";
            }
            echo "</table>";
        }
        else{
            echo "Nothing in cart";
        }

        $conn->close();

    ?>
    </table>


    <a href="checkout2.html"><button>Checkout</button></a>

</body>